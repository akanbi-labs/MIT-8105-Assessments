# Portfolio 3 — Transactions and Concurrency

**Course:** MIT 8103 — Advanced Database Systems  
**Case study:** Olaham Academy Training and Learner Management Database (simulated)  
**Database:** `olaham_academy_db`  
**DBMS:** PostgreSQL 18, administered using pgAdmin 4

## 1. Objective

Demonstrate transaction control (`COMMIT` and `ROLLBACK`), transaction isolation, and concurrency control in the existing Olaham Academy database. All examples use synthetic test records; they are not actual academy operational data.

## 2. Database objects used

- `facilitators` — used to demonstrate persistence, rollback and transaction visibility.
- `concurrency_test` — a small test table with `id` and `available_slots` to demonstrate concurrent updates and row locking.

The `concurrency_test` table starts with `id = 1` and `available_slots = 10` for the final two-update experiment.

## 3. Practical demonstrations and results

### 3.1 COMMIT

A transaction inserted a fictional facilitator and ran `COMMIT`. A subsequent `SELECT` returned the inserted record, demonstrating that the committed change was retained.

**Evidence:** `screenshots/01_Commit.png`

### 3.2 ROLLBACK

A separate transaction attempted to insert a fictional facilitator and ran `ROLLBACK`. The verification `SELECT` returned no matching rows, demonstrating reversal of an uncommitted insert.

**Evidence:** `screenshots/02_Rollback.png`

### 3.3 Transaction isolation — READ COMMITTED

Two separate Query Tool connections were used. In the first connection, a transaction inserted an `Isolation Test Facilitator` record without initially committing. A query in the second connection was used to check visibility before commit. After the first connection committed, the second connection returned the facilitator record (observed facilitator ID: `6`).

This demonstrates the intended `READ COMMITTED` behaviour: changes from an uncommitted transaction are not visible to a different connection, while a fresh statement after commit can see them. The before-commit screenshot is necessary to substantiate the full comparison.

**Evidence:**
- `screenshots/03_Isolation_Before_Commit.png`
- `screenshots/04_Isolation_After_Commit.png`

### 3.4 Concurrency control — row-level locking

The `concurrency_test` table was prepared with 10 available slots. Two separate PostgreSQL connections attempted to decrement the same row inside transactions. While the first transaction held its update lock, the second update waited. After the first transaction committed, the second update completed. The final verification showed **8 available slots**, consistent with two successful decrements from 10.

This demonstrates PostgreSQL's coordination of concurrent modifications to the same row, avoiding a lost update in this specific `available_slots = available_slots - 1` scenario.

**Evidence:**
- `screenshots/05_Concurrency_Waiting.png`
- `screenshots/06_Concurrency_Completed.png`
- `screenshots/07_Concurrency_Final_Result.png`

## 4. Evidence summary

| Lecturer's requirement | Evidence |
| --- | --- |
| Commit | Successful insert and subsequent record retrieval |
| Rollback | Insert reversed; verification returned no record |
| Isolation | Visibility before and after commit using separate database connections |
| Concurrency issue or control | Second update waited for the first; both completed, final slot count 8 |
| Screenshots / output | Images in the `screenshots/` directory |

## 5. Project files

```text
Portfolio-3-Transactions-Concurrency/
├── Olaham_Academy_Portfolio_3.sql
├── README.md
└── screenshots/
    ├── 01_Commit.png
    ├── 02_Rollback.png
    ├── 03_Isolation_Before_Commit.png
    ├── 04_Isolation_After_Commit.png
    ├── 05_Concurrency_Waiting.png
    ├── 06_Concurrency_Completed.png
    └── 07_Concurrency_Final_Result.png
```

## 6. How to review or reproduce

1. Connect to `olaham_academy_db` in PostgreSQL 18 using pgAdmin 4.
2. Review the statements and comments in `Olaham_Academy_Portfolio_3.sql`.
3. Run the **COMMIT** and **ROLLBACK** demonstrations independently, checking their verification queries.
4. For **isolation** and **concurrency**, open **two separate database connections**, execute only the specified statements in sequence, and keep the first transaction open until the second connection performs its check or update.
5. Review the corresponding screenshots to compare observed output.

**Caution:** Do not run the entire SQL file in one execution. It contains multiple demonstrations and intentionally separate transaction steps. Executing everything together can change or invalidate the results. Repeated inserts may also create duplicate test records. Reset only the synthetic test data when necessary.

## 7. Technical reflection

This portfolio illustrated the difference between saving and reversing database changes, and why transaction boundaries matter. The isolation exercise required distinct database connections: checking the record after committing too early could not demonstrate the before-commit state. The concurrency exercise also showed that an open transaction can block another update; transaction state and lock ownership must be managed carefully to obtain valid evidence.

## 8. Limitations and scope

The results demonstrate the observed behaviours in a controlled test, not a production deployment or an exhaustive assessment of all isolation levels. The concurrency test used a single row and two database connections. Actual outcomes and generated record IDs may differ if the tests are repeated.

## 9. References

**References:** MIT 8103 Advanced Database Systems continuous assessment brief; PostgreSQL documentation on transactions, isolation and explicit locking (https://www.postgresql.org/docs/current/transaction-iso.html).

---

