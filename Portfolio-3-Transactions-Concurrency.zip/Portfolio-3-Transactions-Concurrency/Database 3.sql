
-- PORTFOLIO 3: TRANSACTIONS AND CONCURRENCY
-- REQUIREMENT 1: COMMIT

BEGIN;

INSERT INTO facilitators
(full_name, specialisation)
VALUES
('Portfolio 3 Test Facilitator',
 'Transaction Testing');

COMMIT;

-- Verify that the record was saved

SELECT
    facilitator_id,
    full_name,
    specialisation
FROM facilitators
WHERE full_name = 'Portfolio 3 Test Facilitator';



-- PORTFOLIO 3: REQUIREMENT 2
-- ROLLBACK DEMONSTRATION

BEGIN;

INSERT INTO facilitators
(full_name, specialisation)
VALUES
('Rollback Test Facilitator',
 'Database Transaction Testing');

ROLLBACK;

-- Verify that the record was not saved

SELECT
    facilitator_id,
    full_name,
    specialisation
FROM facilitators
WHERE full_name = 'Rollback Test Facilitator';




-- SESSION A: Start transaction

BEGIN;

SET TRANSACTION ISOLATION LEVEL READ COMMITTED;

INSERT INTO facilitators
(full_name, specialisation)
VALUES
('Isolation Test Facilitator',
 'Transaction Isolation');



-- SESSION B: Check uncommitted data

SELECT
    facilitator_id,
    full_name
FROM facilitators
WHERE full_name = 'Isolation Test Facilitator';


DELETE FROM facilitators
WHERE full_name = 'Isolation Test Facilitator';


BEGIN;

SET TRANSACTION ISOLATION LEVEL READ COMMITTED;

INSERT INTO facilitators
(full_name, specialisation)
VALUES
('Isolation Test Facilitator', 'Transaction Isolation');

