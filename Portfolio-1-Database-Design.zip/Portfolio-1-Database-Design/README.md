# Olaham Academy — Advanced Database Systems Portfolio 1

**Course:** MIT 8103 — Advanced Database Systems  
**Portfolio activity:** 1 — Database Design and Modelling (7 marks)  
**DBMS:** PostgreSQL 18  
**Interface:** pgAdmin 4  
**Database:** `olaham_academy_db`

## Overview

This individual academic project develops a **proposed** Training and Learner Management Database for Olaham Academy. It models how programmes, cohorts, participants, facilitators, sessions, enrolments, assessments, and submissions could be managed. The records used in this exercise are fictional demonstration data, not actual Olaham Academy learner records or an extract of its internal system.

## Objectives

1. Design a relational database for a realistic educational training scenario.
2. Implement tables, keys, relationships, and constraints in PostgreSQL.
3. Populate and query a small simulated dataset.
4. Demonstrate data-integrity controls and explain normalisation to 3NF.
5. Document the implementation using an ER diagram, SQL script, and screenshots.

## Database Schema

| Table | Primary key | Role |
|---|---|---|
| `programmes` | `programme_id` | Training programmes |
| `participants` | `participant_id` | Learner profiles |
| `facilitators` | `facilitator_id` | Trainers |
| `cohorts` | `cohort_id` | Programme batches; references programmes |
| `enrolments` | `enrolment_id` | Participant registrations into cohorts |
| `sessions` | `session_id` | Scheduled teaching sessions |
| `assessments` | `assessment_id` | Assignments and capstones for cohorts |
| `submissions` | `submission_id` | Submission scores linked to enrolments and assessments |

### Main relationships

- One programme can have multiple cohorts (`programmes` → `cohorts`).
- Participants and cohorts have a many-to-many relationship resolved through `enrolments`.
- One cohort can have multiple sessions and assessments.
- One facilitator can teach multiple sessions.
- An enrolment can have submissions for different assessments.

See `screenshots/02_ER_Diagram.png` for the exported entity-relationship diagram.

## Repository Contents

```text
Portfolio-1-Database-Design/
├── Olaham_Academy_Portfolio_1.sql
├── normalisation.md
├── README.md
└── screenshots/
    ├── 01_Database_Tables.png
    ├── 02_ER_Diagram.png
    ├── 03_Table_Record_Counts.png
    ├── 04_Participant_Enrolments.png
    ├── 05_Unique_Constraint.png
    ├── 06_Check_Constraint.png
    └── 07_Foreign_Key_Constraint.png
```

> Screenshot filenames above are the intended naming convention; include only screenshots you have actually captured and saved. Keep your entire SQL work in the single `.sql` file used during development.

## Reproducing and Testing the Database

1. Install PostgreSQL and pgAdmin 4.
2. Connect pgAdmin to a local PostgreSQL server.
3. Create a database named `olaham_academy_db`.
4. Open **Query Tool** for that database.
5. Open `Olaham_Academy_Portfolio_1.sql`. On a **fresh, empty database only**, execute the table creation statements first, followed by sample-data inserts in dependency order: programmes, participants, facilitators, cohorts, enrolments, sessions, assessments, submissions.
6. Run the `SELECT` queries to verify the resulting tables and relationships.
7. Run each negative constraint test **separately**; failure is the expected result. If the session is in an aborted transaction, execute `ROLLBACK;` before the next test.

**Important:** The single development script contains commands that create tables and insert records. Do **not** run the whole script again against an existing populated database, because that can cause duplicate-table and duplicate-record errors. Highlight only the statement(s) you want to execute in pgAdmin.

### Verification queries

```sql
SELECT table_name
FROM information_schema.tables
WHERE table_schema = 'public' AND table_type = 'BASE TABLE'
ORDER BY table_name;

SELECT 'participants' AS table_name, COUNT(*) AS total_records FROM participants
UNION ALL SELECT 'programmes', COUNT(*) FROM programmes
UNION ALL SELECT 'cohorts', COUNT(*) FROM cohorts
UNION ALL SELECT 'facilitators', COUNT(*) FROM facilitators
UNION ALL SELECT 'enrolments', COUNT(*) FROM enrolments
UNION ALL SELECT 'sessions', COUNT(*) FROM sessions
UNION ALL SELECT 'assessments', COUNT(*) FROM assessments
UNION ALL SELECT 'submissions', COUNT(*) FROM submissions;
```

For the demonstrated sample dataset, the expected counts **after successful committed inserts** are: 5 participants, 3 programmes, 2 cohorts, 3 facilitators, 5 enrolments, 2 sessions, 2 assessments, and 3 submissions. These are test expectations, not a claim about the academy's real enrolment numbers.

### Constraint Tests and Observations

| Test | Attempt | Expected / observed error |
|---|---|---|
| UNIQUE | Add another participant with `amina@example.com` | Duplicate email rejected, SQLSTATE `23505` |
| CHECK | Enrol a participant with status `Unknown` | Invalid status rejected, SQLSTATE `23514` |
| FOREIGN KEY | Enrol `participant_id = 99999` | Nonexistent participant rejected, SQLSTATE `23503` |

The corresponding pgAdmin screenshots show the error messages. These errors are **expected evidence of successful constraint enforcement**.

## Normalisation

The design aims to satisfy 1NF, 2NF, and 3NF by storing atomic attributes, using suitable keys, and separating programme, participant, cohort, and assessment facts. For a fuller explanation, see [`normalisation.md`](normalisation.md).

## Design Limitations and Future Improvements

- The initial `submissions` table permits nonnegative scores but does not yet ensure scores stay below the corresponding `maximum_score`.
- The initial foreign keys do not yet enforce that an assessment and its referenced enrolment belong to the same cohort.
- The sample dataset is small; larger datasets will be needed for meaningful query-plan and indexing performance experiments in Portfolio 2.
- The present model is an academic prototype and not a production system; personal-data security, role-based access, backups, and fuller business rules would require additional work.

## Reflection 
I designed eight related tables to represent the main activities of a training academy. A key design decision was introducing an `enrolments` table to handle the many-to-many relationship between participants and cohorts. I tested the schema using simulated records and deliberately invalid inserts to see how PostgreSQL enforces constraints. [Add the specific challenges you encountered, what you changed, and what you learned in your own words.]





