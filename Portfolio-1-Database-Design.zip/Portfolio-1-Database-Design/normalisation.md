# Database Normalisation — Olaham Academy

**Course:** MIT 8103 Advanced Database Systems  
**Portfolio:** 1 — Database Design and Modelling  
**Case study:** Proposed Training and Learner Management Database for Olaham Academy

## 1. Introduction

This project models a training and learner management system for Olaham Academy. It uses **simulated participant and training data** for academic demonstration, not the academy's private operational records. The PostgreSQL database contains eight tables: `programmes`, `participants`, `facilitators`, `cohorts`, `enrolments`, `sessions`, `assessments`, and `submissions`.

Normalisation organises data to reduce redundancy and insertion, update, and deletion anomalies. The design aims to meet First Normal Form (1NF), Second Normal Form (2NF), and Third Normal Form (3NF).

## 2. First Normal Form (1NF)

A relation is in 1NF when its columns hold atomic values for the intended model, there are no repeating groups, and rows are uniquely identifiable. In this design, each table has a primary key (for example, `participant_id`, `programme_id`, or `enrolment_id`). A participant's name, email, and registration date occupy separate columns. Rather than storing multiple cohort names or participants in a single field, the `enrolments` table stores one participant–cohort association per row.

**Example:** `participants(participant_id, full_name, email, registration_date)`.

## 3. Second Normal Form (2NF)

A relation is in 2NF when it is in 1NF and every non-prime attribute depends on the *whole* of every candidate key rather than only part of a composite candidate key. In this model, all eight tables have a single-column primary key, which avoids partial dependencies on their primary keys. For `enrolments`, the combination (`participant_id`, `cohort_id`) is also constrained to be unique, and `status` describes that complete participant–cohort enrolment, not the participant or cohort alone.

**Example:** `enrolments(enrolment_id, participant_id, cohort_id, status)`; the same participant may enrol in different cohorts, each with its own status.

## 4. Third Normal Form (3NF)

A relation is in 3NF when it is in 2NF and non-key facts are not stored as transitive dependencies on a key. The design separates facts by subject:

- `programmes` stores programme title and description; `cohorts` stores programme occurrences and references `programmes` using `programme_id`.
- `participants` stores learner contact details; `enrolments` references a participant using `participant_id` rather than copying their name or email.
- `facilitators` stores trainer details; `sessions` references a facilitator using `facilitator_id`.
- `assessments` stores assessment information; `submissions` references assessments and enrolments rather than repeating programme and participant descriptions.

**Example of an avoided update anomaly:** Changing a programme title requires updating one row in `programmes` rather than all of its cohorts or enrolments.

These design decisions support 3NF under the intended business rules. Full formal verification would require documenting all functional dependencies and candidate keys; this explanation focuses on the dependencies represented in the implemented schema.

## 5. Keys, Relationships, and Integrity

- **Primary keys:** Unique row identifiers such as `participant_id` and `submission_id`.
- **Foreign keys:** `cohorts.programme_id`, `enrolments.participant_id`, `enrolments.cohort_id`, `sessions.facilitator_id`, `sessions.cohort_id`, `assessments.cohort_id`, `submissions.enrolment_id`, and `submissions.assessment_id`.
- **UNIQUE constraint:** `participants.email` prevents duplicate email addresses (observed SQLSTATE `23505`).
- **CHECK constraint:** `enrolments.status` permits only `Active`, `Completed`, and `Withdrawn` (observed SQLSTATE `23514`).
- **Foreign-key constraint:** An enrolment cannot refer to a nonexistent participant (observed SQLSTATE `23503`).

**Current limitation:** The initial schema checks that a submission's score is nonnegative, but it does not yet enforce that the score is at most the relevant assessment's maximum, or that the assessment belongs to the same cohort as the referenced enrolment. Those are additional business rules for a later refinement.

## 6. Conclusion

The eight-table Olaham Academy design separates programmes, cohorts, participants, facilitators, enrolments, sessions, assessments, and submissions into related structures. Its keys and constraints help reduce duplicated information and protect referential integrity. The documented 1NF–3NF rationale provides a foundation for subsequent portfolio work on query optimisation, transactions, and advanced data models.
