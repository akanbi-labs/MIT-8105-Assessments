
SELECT current_database();

-- PORTFOLIO 1: OLAHAM ACADEMY
-- Database Design and Modelling

CREATE TABLE programmes (
    programme_id SERIAL PRIMARY KEY,
    title VARCHAR(150) NOT NULL UNIQUE,
    description TEXT
);

CREATE TABLE participants (
    participant_id SERIAL PRIMARY KEY,
    full_name VARCHAR(120) NOT NULL,
    email VARCHAR(150) NOT NULL UNIQUE,
    registration_date DATE DEFAULT CURRENT_DATE
);

CREATE TABLE facilitators (
    facilitator_id SERIAL PRIMARY KEY,
    full_name VARCHAR(120) NOT NULL,
    specialisation VARCHAR(150)
);

CREATE TABLE cohorts (
    cohort_id SERIAL PRIMARY KEY,
    programme_id INT NOT NULL REFERENCES programmes(programme_id),
    cohort_name VARCHAR(100) NOT NULL,
    start_date DATE NOT NULL,
    end_date DATE NOT NULL,
    CHECK (end_date >= start_date),
    UNIQUE (programme_id, cohort_name)
);

CREATE TABLE enrolments (
    enrolment_id SERIAL PRIMARY KEY,
    participant_id INT NOT NULL REFERENCES participants(participant_id),
    cohort_id INT NOT NULL REFERENCES cohorts(cohort_id),
    status VARCHAR(20) NOT NULL DEFAULT 'Active',
    CHECK (status IN ('Active', 'Completed', 'Withdrawn')),
    UNIQUE (participant_id, cohort_id)
);

CREATE TABLE sessions (
    session_id SERIAL PRIMARY KEY,
    cohort_id INT NOT NULL REFERENCES cohorts(cohort_id),
    facilitator_id INT NOT NULL REFERENCES facilitators(facilitator_id),
    session_title VARCHAR(150) NOT NULL,
    session_date TIMESTAMP NOT NULL
);

CREATE TABLE assessments (
    assessment_id SERIAL PRIMARY KEY,
    cohort_id INT NOT NULL REFERENCES cohorts(cohort_id),
    title VARCHAR(150) NOT NULL,
    maximum_score INT NOT NULL CHECK (maximum_score > 0),
    UNIQUE (assessment_id, cohort_id)
);

CREATE TABLE submissions (
    submission_id SERIAL PRIMARY KEY,
    enrolment_id INT NOT NULL REFERENCES enrolments(enrolment_id),
    assessment_id INT NOT NULL REFERENCES assessments(assessment_id),
    score NUMERIC(6,2) CHECK (score >= 0),
    submitted_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    UNIQUE (enrolment_id, assessment_id)
);


SELECT table_name
FROM information_schema.tables
WHERE table_schema = 'public'
AND table_type = 'BASE TABLE'
ORDER BY table_name;



INSERT INTO programmes (title, description)
VALUES
('Digital Skills for Everyday Success',
 'A practical digital skills training programme'),

('Professional Development',
 'Training in workplace and professional skills'),

('Digital Entrepreneurship',
 'Training in digital business and entrepreneurship');

SELECT * FROM programmes;


INSERT INTO participants (full_name, email)
VALUES
('Amina Yusuf', 'amina@example.com'),
('David Okoro', 'david@example.com'),
('Sarah Bello', 'sarah@example.com'),
('Michael Ade', 'michael@example.com'),
('Fatima Ibrahim', 'fatima@example.com');

SELECT * FROM participants;


INSERT INTO facilitators (full_name, specialisation)
VALUES
('John Adewale', 'Digital Skills'),
('Grace Okafor', 'Professional Development'),
('Peter Musa', 'Entrepreneurship');

SELECT * FROM facilitators;



INSERT INTO cohorts
(programme_id, cohort_name, start_date, end_date)
VALUES
(
 (SELECT programme_id FROM programmes
  WHERE title = 'Digital Skills for Everyday Success'),
 'Cohort 3', '2026-06-01', '2026-08-31'
),
(
 (SELECT programme_id FROM programmes
  WHERE title = 'Professional Development'),
 'Cohort 1', '2026-07-01', '2026-09-30'
);

SELECT * FROM cohorts;


INSERT INTO sessions
(cohort_id, facilitator_id, session_title, session_date)
VALUES
(
 (SELECT cohort_id FROM cohorts WHERE cohort_name = 'Cohort 3'),
 (SELECT facilitator_id FROM facilitators WHERE full_name = 'John Adewale'),
 'Introduction to Digital Skills',
 '2026-06-05 10:00:00'
),
(
 (SELECT cohort_id FROM cohorts WHERE cohort_name = 'Cohort 1'),
 (SELECT facilitator_id FROM facilitators WHERE full_name = 'Grace Okafor'),
 'Workplace Communication',
 '2026-07-07 10:00:00'
);

SELECT * FROM sessions;



INSERT INTO assessments (cohort_id, title, maximum_score)
VALUES
(
 (SELECT cohort_id FROM cohorts WHERE cohort_name = 'Cohort 3'),
 'Digital Skills Capstone Project', 100
),
(
 (SELECT cohort_id FROM cohorts WHERE cohort_name = 'Cohort 1'),
 'Professional Skills Assessment', 100
);

SELECT * FROM assessments;



INSERT INTO submissions (enrolment_id, assessment_id, score)
SELECT e.enrolment_id, a.assessment_id, v.score
FROM (
 VALUES
 ('david@example.com', 'Digital Skills Capstone Project', 85.00),
 ('amina@example.com', 'Digital Skills Capstone Project', 78.50),
 ('fatima@example.com', 'Professional Skills Assessment', 91.00)
) AS v(email, assessment_title, score)
JOIN participants p ON p.email = v.email
JOIN enrolments e ON e.participant_id = p.participant_id
JOIN assessments a
    ON a.cohort_id = e.cohort_id
   AND a.title = v.assessment_title;

SELECT * FROM submissions;




SELECT
    p.full_name AS participant_name,
    pr.title AS programme,
    c.cohort_name,
    e.status
FROM enrolments e
JOIN participants p
    ON e.participant_id = p.participant_id
JOIN cohorts c
    ON e.cohort_id = c.cohort_id
JOIN programmes pr
    ON c.programme_id = pr.programme_id
ORDER BY p.full_name;



SELECT
    tc.table_name,
    kcu.column_name,
    ccu.table_name AS referenced_table,
    ccu.column_name AS referenced_column
FROM information_schema.table_constraints tc
JOIN information_schema.key_column_usage kcu
    ON tc.constraint_name = kcu.constraint_name
   AND tc.table_schema = kcu.table_schema
JOIN information_schema.constraint_column_usage ccu
    ON tc.constraint_name = ccu.constraint_name
   AND tc.table_schema = ccu.table_schema
WHERE tc.constraint_type = 'FOREIGN KEY'
  AND tc.table_schema = 'public'
ORDER BY tc.table_name;




SELECT 'participants' AS table_name, COUNT(*) AS total_records
FROM participants

UNION ALL

SELECT 'programmes', COUNT(*)
FROM programmes

UNION ALL

SELECT 'cohorts', COUNT(*)
FROM cohorts

UNION ALL

SELECT 'facilitators', COUNT(*)
FROM facilitators

UNION ALL

SELECT 'enrolments', COUNT(*)
FROM enrolments

UNION ALL

SELECT 'sessions', COUNT(*)
FROM sessions

UNION ALL

SELECT 'assessments', COUNT(*)
FROM assessments

UNION ALL

SELECT 'submissions', COUNT(*)
FROM submissions;
