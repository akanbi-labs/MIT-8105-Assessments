# Portfolio 5: Distributed and Cloud Database Analysis

**Course:** MIT 8103 — Advanced Database Systems  
**Case study:** Olaham Academy  
**Database model:** MongoDB document database  
**Implementation status:** Local standalone MongoDB; proposed distributed/cloud design (not deployed)

## 1. Objective and scope

This exercise examines how Olaham Academy's proposed learner portfolio database could be made more available and scalable through distributed database techniques. It extends the fictional `olaham_academy_nosql` case study used in Portfolio 4, particularly the `student_portfolios` collection, which contains learner details, arrays of skills, and embedded project records.

The work consists of **local configuration checks** and a **conceptual distributed/cloud database design**. No replication, sharding or cloud deployment was implemented or tested.

## 2. Observed local setup and technical evidence

The following commands were run in MongoDB Shell through MongoDB Compass, connected to `localhost:27017`:

```javascript
db.adminCommand({ hello: 1 })
rs.status()
db.adminCommand({ getCmdLineOpts: 1 })
```

| Check | Observed result | Interpretation | Evidence |
|---|---|---|---|
| Server response | `hello` returned `ok: 1` and `isWritablePrimary: true` | The server responded successfully; this **does not establish replica-set replication** | `screenshots/01_MongoDB_Server_Configuration.png` |
| Replication status | `MongoServerError[NoReplicationEnabled]: not running with --replSet` | The local server is **not configured as a replica set** | `screenshots/02_MongoDB_Replication_Status.png` |
| Startup configuration | Configuration showed `127.0.0.1`, port `27017`, and `service: true`, with local Windows file paths | MongoDB is running as a local Windows service, not as an evidenced cloud deployment | `screenshots/03_MongoDB_Deployment_Configuration.png` |

The screenshots reflect the configuration at the time of testing; they do not prove high availability, failover or distributed operation.

## 3. Proposed distributed architecture

For a future production learner management system, Olaham Academy could use a **three-member MongoDB replica set** distributed across separate fault domains or availability zones:

- **Primary member:** receives writes and coordinates replication.
- **Secondary member 1:** maintains a replicated copy of the data.
- **Secondary member 2:** maintains another copy and can participate in electing a new primary.
- **Application tier:** connects through a replica-set-aware MongoDB driver, rather than relying on one hard-coded standalone host.

**Diagram:** `olaham_database_architecture.png` — proposed architecture only; not an actual deployed configuration.

In this design, primary-to-secondary replication is asynchronous. Replica members should be placed in independent failure domains; putting all members on one machine would not provide meaningful hardware fault tolerance. Operational safeguards would include access control, TLS, backups, monitoring and recovery testing.

## 4. Replication and availability

Replication helps maintain multiple copies of Olaham Academy's training and project data. If the primary member becomes unavailable, an eligible secondary may be elected primary when a majority is reachable. This can reduce downtime, but **failover is not instantaneous or guaranteed**, especially during network partitions or loss of a majority.

Replication is **not** a substitute for backups: deletions and incorrect updates can be replicated too. Separate, tested backups and recovery procedures would still be required.

## 5. Consistency and transaction considerations

Olaham Academy may require reliable updates when learners submit projects or coordinators change completion status. In a replica set, appropriate **write concern** and **read concern** settings can improve durability and consistency guarantees. For important updates, a majority write concern could be considered so a write is acknowledged after reaching a majority of voting data-bearing members, subject to deployment configuration.

Reading from secondaries can involve replication lag; the application must decide whether it needs the most recent confirmed data or can tolerate slightly stale views. The final choice depends on the operation and the trade-off among latency, availability and consistency. These options were **discussed only**, not configured or benchmarked during this exercise.

## 6. Sharding and future scalability

If Olaham Academy later serves much larger learner populations, sharding could distribute data across multiple shards. A possible future shard-key candidate might relate to a stable, high-cardinality learner identifier, but selecting a shard key requires analysing real query patterns, cardinality, data distribution and the risk of uneven load.

The current demonstration contains only a small fictional set of learner portfolios. **Sharding is not necessary or justified by the current workload**, and no sharded cluster was implemented. Sharding introduces routing, operational complexity and potential cross-shard query costs; it should be evaluated only when growth creates a demonstrable need.

## 7. Cloud deployment proposal

One deployment option would be a managed MongoDB cluster configured for replica-set availability across suitable availability zones. An application server could authenticate to the cluster over a secured connection and access learner portfolios using appropriately scoped database roles.

A practical deployment plan would include: environment and region selection, network access controls, encryption in transit, user roles, backup settings, monitoring, deployment testing and a documented recovery procedure. This is a **proposal**, not a claim that the local database was moved to a cloud provider.

## 8. Evaluation, limitations and reflection

This activity confirmed that the existing MongoDB setup responds to administrative queries and is running locally without replica-set functionality. It also produced a conceptual design explaining how replication, availability, consistency and possible future sharding could apply to Olaham Academy.

**Limitation:** The exercise does not provide replication-status output from a replica set, failover tests, sharding metrics or live cloud deployment evidence. Those capabilities remain proposed rather than implemented.

**Individual reflection (review and personalise):** Through the configuration checks, I learned to distinguish a working MongoDB server from a distributed deployment. The `rs.status()` error was useful evidence: it showed that a successful local connection does not automatically imply replication. I also learned that replication can improve availability, but operational choices about consistency, backups and recovery still matter.

## 9. Sources and AI use

- MIT 8103 Advanced Database Systems continuous assessment instructions, Portfolio 5 deliverables.
- MongoDB documentation: <https://www.mongodb.com/docs/manual/replication/>
- MongoDB documentation: <https://www.mongodb.com/docs/manual/sharding/>
- MongoDB documentation: <https://www.mongodb.com/docs/manual/reference/read-concern/>
- MongoDB documentation: <https://www.mongodb.com/docs/manual/reference/write-concern/>

**AI-use declaration (edit to reflect actual use):** ChatGPT was used to explain concepts, organise the analysis and draft documentation. I reviewed the proposed explanations against my MongoDB Shell results and screenshots. I am responsible for checking the accuracy of all submitted material and explaining the work.
