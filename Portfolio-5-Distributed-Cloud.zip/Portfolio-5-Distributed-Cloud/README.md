# Olaham Academy — Portfolio 5: Distributed and Cloud Database Exercise

**Course:** MIT 8103 — Advanced Database Systems  
**Case study:** Olaham Academy (proposed learner portfolio database)  
**Database:** `olaham_academy_nosql` — MongoDB  
**Assessment component:** Portfolio 5 (6 marks)

## Overview

This portfolio examines a local MongoDB setup and proposes a distributed/cloud architecture for Olaham Academy's learner portfolio system. It follows the **discussion or setup** option permitted by the assignment. The local configuration was checked in MongoDB Shell; **no replica set, sharded cluster or cloud environment was actually deployed**.

The same Olaham Academy case study is used across the course portfolios. The MongoDB `student_portfolios` collection stores fictional learner information, skills arrays and project records from Portfolio 4.

## Lecturer's required evidence

The assignment calls for a distributed/cloud database **discussion or setup**, addressing relevant concepts such as replication, sharding, availability, consistency or deployment evidence. The materials in this folder provide:

1. Administrative command outputs from the existing local MongoDB service.
2. A proposed replica-set architecture diagram.
3. A technical analysis of replication, availability, consistency, sharding and possible cloud deployment.
4. A reflection distinguishing observed functionality from proposed functionality.

## Technical environment and observations

- **Software:** MongoDB Community Server and MongoDB Compass with MongoDB Shell (`mongosh`).
- **Connection:** `localhost:27017`.
- **Local startup:** Windows MongoDB service, bound to `127.0.0.1` on port `27017` in the observed configuration.
- **Replication:** Not enabled; `rs.status()` returned `MongoServerError[NoReplicationEnabled]: not running with --replSet`.

The `hello` response included `ok: 1`, confirming the command ran, but **not** proving replication or cloud hosting.

## Commands used

Run these one at a time in MongoDB Compass → Open MongoDB Shell:

```javascript
// Inspect the connected server
db.adminCommand({ hello: 1 })

// Check whether a replica set is enabled
rs.status()

// Inspect startup configuration
db.adminCommand({ getCmdLineOpts: 1 })
```

`rs.status()` is expected to return an error on the observed standalone installation. This is part of the evidence, **not a failed assignment**.

## Files and screenshots

```text
Portfolio-5-Distributed-Cloud/
├── README.md
├── distributed_database_analysis.md
├── olaham_database_architecture.png
└── screenshots/
    ├── 01_MongoDB_Server_Configuration.png
    ├── 02_MongoDB_Replication_Status.png
    └── 03_MongoDB_Deployment_Configuration.png
```

The architecture PNG is a proposed black-and-white diagram. Include it only after it has been saved; it must be labelled **conceptual/not deployed**.

## What the proposed design covers

- **Replication:** A primary with two secondary replicas for redundant copies and potential elections/failover.
- **Availability:** Majority-based elections can support service continuity, but network partitions or lack of a majority can prevent writes.
- **Consistency:** Read/write concern choices and secondary replication lag affect data freshness and durability.
- **Sharding:** A possible future scaling approach; not needed or implemented for the current small fictional dataset.
- **Cloud deployment:** A possible managed, secured MongoDB replica-set service; not yet deployed.

See [`distributed_database_analysis.md`](distributed_database_analysis.md) for the full discussion, caveats and references.

## How the work was verified

The three MongoDB Shell commands were run against the local server and their outputs were captured as screenshots. The proposed architecture is analytical evidence only, not a test result. This distinction is important for accurate technical verification.

## Technical reflection

The configuration checks helped distinguish local database operation from distributed database capabilities. The replica-set status command confirmed that the current server has no replication enabled. The proposed architecture illustrates the extra infrastructure and consistency decisions needed for a more available production database.

*Review and personalise this reflection before submitting it as individual work.*

## AI-use declaration

ChatGPT assisted with planning the demonstration, explaining MongoDB concepts, and drafting the README and analysis. The recorded command outputs are from the student's local MongoDB installation. The student should review the files, verify the explanations and declare the final use accurately in the assessment submission.

## References

- MIT 8103 Advanced Database Systems continuous assessment brief.
- MongoDB replication: <https://www.mongodb.com/docs/manual/replication/>
- MongoDB sharding: <https://www.mongodb.com/docs/manual/sharding/>
- MongoDB read concern: <https://www.mongodb.com/docs/manual/reference/read-concern/>
- MongoDB write concern: <https://www.mongodb.com/docs/manual/reference/write-concern/>
