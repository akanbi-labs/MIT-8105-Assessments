# Portfolio 2 — Query Processing and Optimisation

**Course:** MIT 8103 — Advanced Database Systems  
**Case study:** Olaham Academy (proposed Training and Learner Management Database)  
**Database:** `olaham_academy_db`  
**DBMS:** PostgreSQL 18 (managed through pgAdmin 4)  
**Assessment component:** Portfolio 2 — 7 marks

## 1. Objective

This portfolio demonstrates SQL query processing, examination of execution plans, index creation, and a brief analysis of query performance in the proposed Olaham Academy database. The study uses simulated learner records and a separate, synthetic activity-log dataset; it does not represent the academy's actual internal records.

## 2. Database and test data

The relational database developed in Portfolio 1 contains eight main tables: `participants`, `programmes`, `cohorts`, `facilitators`, `enrolments`, `sessions`, `assessments`, and `submissions`.

A ninth table, `portfolio2_activity_log`, was created **only for Portfolio 2 performance testing**. It contains 100,000 generated activity records linked to enrolments and includes the fields `log_id`, `enrolment_id`, `event_type`, and `event_time`. This larger dataset allows a more meaningful demonstration of query execution and indexing than the small learner sample alone.

## 3. SQL queries and query results

Queries were run in pgAdmin to retrieve information from multiple related tables, including:

- Participant enrolments and associated programmes/cohorts.
- Participant counts per cohort (3 in Digital Skills for Everyday Success, Cohort 3; 2 in Professional Development, Cohort 1).
- Recorded assessment submissions and scores (91.00, 85.00, and 78.50).
- Database table counts and verification of the generated 100,000-row activity log.

The complete SQL used for this portfolio is kept together in **`Olaham_Academy_Portfolio_2.sql`**. Additional SQL queries, if included in that script, should be documented only after they have been run and their results verified.

## 4. Execution plan before optimisation

The benchmark query counts `Assessment` events within the interval from **2026-11-01 (inclusive)** to **2026-11-08 (exclusive)**:

```sql
EXPLAIN (ANALYZE, BUFFERS)
SELECT COUNT(*)
FROM portfolio2_activity_log
WHERE event_type = 'Assessment'
  AND event_time >= '2026-11-01'
  AND event_time < '2026-11-08';
```

The initial plan used a **Sequential Scan (`Seq Scan`)**. The plan showed **475 matching records**, **99,525 rows removed by the filter**, **736 shared buffer hits**, and an **execution time of 25.981 ms**.

## 5. Indexing and optimisation

A composite B-tree index was created on the two filtering columns, followed by an update of query-planner statistics:

```sql
CREATE INDEX idx_activity_type_time
ON portfolio2_activity_log (event_type, event_time);

ANALYZE portfolio2_activity_log;
```

The index can be verified using:

```sql
SELECT indexname, indexdef
FROM pg_indexes
WHERE schemaname = 'public'
  AND tablename = 'portfolio2_activity_log';
```

The same benchmark query was run again with `EXPLAIN (ANALYZE, BUFFERS)` after the index was created. PostgreSQL selected an **Index Only Scan** using `idx_activity_type_time`, with **zero heap fetches**, **5 shared buffer hits**, and an **execution time of 0.221 ms**.

## 6. Performance analysis

| Metric | Before indexing | After indexing |
|---|---:|---:|
| Execution method | Sequential Scan | Index Only Scan |
| Execution time | 25.981 ms | 0.221 ms |
| Shared buffer hits | 736 | 5 |
| Heap fetches | Not applicable to the sequential scan | 0 |

For these two observed executions, the recorded execution time decreased by approximately **99.15%**, equivalent to an observed **117.6× speedup**. The indexed plan also accessed substantially fewer shared buffers.

These figures describe **one before-and-after comparison**, not a controlled benchmark average. Cache state, server load, planner statistics, and repeated executions may change measured times. Indexes also use storage and add maintenance overhead for writes. See `performance_analysis.md` for the accompanying explanation.

## 7. Evidence and files

Recommended organisation:

```text
Portfolio-2-Query-Optimisation/
├── Olaham_Academy_Portfolio_2.sql
├── README.md
├── performance_analysis.md
└── screenshots/
    ├── Database_Verification.png
    ├── Cohort_Counts.png
    ├── Assessment_Scores.png
    ├── Performance_Test_Data.png
    ├── Execution_Plan_Before.png
    ├── Index_Verification.png
    └── Execution_Plan_After.png
```

**Note:** Rename the filenames in this section to match your actual saved screenshots. Include only evidence you have captured. The screenshots of the execution plans should show the actual scan method, buffer data, and execution time; if the final execution time is cut off, capture an additional image with the full result.

## 8. How to review or reproduce the work

1. Open pgAdmin 4 and connect to the PostgreSQL 18 server.
2. Select the existing `olaham_academy_db` database (created during Portfolio 1).
3. Open `Olaham_Academy_Portfolio_2.sql` in the Query Tool.
4. **Do not execute the entire script again against a populated database.** Some statements create tables, insert generated records, or create an index and are intended to run only once.
5. Execute individual `SELECT` queries to inspect learner results and record counts.
6. To reproduce the original **unindexed** plan, use a fresh test copy of the activity-log table without the composite index; do not drop an index from the working database without preparing a backup and understanding the consequences.
7. Use the saved execution-plan screenshots and `performance_analysis.md` to compare the recorded before-and-after results.

## 9. Technical reflection

The small set of learner records was sufficient for demonstrating joins and aggregation but was not suitable for assessing the effects of indexing. Using a separate synthetic activity log allowed the same filtered query to be examined before and after adding a composite index. The change from a Sequential Scan to an Index Only Scan illustrates the impact that an appropriate access path can have for a selective query. The experiment also showed the importance of interpreting execution plans rather than relying solely on one execution-time measurement.

*Review and personalise this paragraph to reflect your own actions, observations, and challenges before submitting it as your individual reflection.*

## 10. References and AI-use declaration

- PostgreSQL documentation: [`EXPLAIN`](https://www.postgresql.org/docs/current/sql-explain.html), [Indexes](https://www.postgresql.org/docs/current/indexes.html), and [`ANALYZE`](https://www.postgresql.org/docs/current/sql-analyze.html).

**GitHub repository:** `[Insert your private repository URL here]`  
**Student name / matriculation number:** `[Add as required]`
