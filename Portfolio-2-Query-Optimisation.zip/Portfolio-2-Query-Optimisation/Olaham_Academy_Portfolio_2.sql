
-- MIT 8103: PORTFOLIO 2
-- Olaham Academy
-- Query Processing and Optimisation

-- Stage 1: Verify existing database records

SELECT 'participants' AS table_name,
       COUNT(*) AS total_records
FROM participants

UNION ALL
SELECT 'programmes', COUNT(*) FROM programmes

UNION ALL
SELECT 'cohorts', COUNT(*) FROM cohorts

UNION ALL
SELECT 'facilitators', COUNT(*) FROM facilitators

UNION ALL
SELECT 'enrolments', COUNT(*) FROM enrolments

UNION ALL
SELECT 'sessions', COUNT(*) FROM sessions

UNION ALL
SELECT 'assessments', COUNT(*) FROM assessments

UNION ALL
SELECT 'submissions', COUNT(*) FROM submissions;



-- Q1: Participants and their programmes

SELECT
    p.full_name AS participant_name,
    pr.title AS programme,
    c.cohort_name,
    e.status
FROM enrolments e
JOIN participants p
    ON e.participant_id = p.participant_id
JOIN cohorts c
    ON e.cohort_id = c.cohort_id
JOIN programmes pr
    ON c.programme_id = pr.programme_id
ORDER BY p.full_name;




-- Q2: Total participants per cohort

SELECT
    pr.title AS programme,
    c.cohort_name,
    COUNT(e.enrolment_id) AS total_participants
FROM cohorts c
JOIN programmes pr
    ON c.programme_id = pr.programme_id
LEFT JOIN enrolments e
    ON c.cohort_id = e.cohort_id
GROUP BY pr.title, c.cohort_id, c.cohort_name
ORDER BY pr.title, c.cohort_name;



-- Q3: Participant assessment scores

SELECT
    p.full_name AS participant_name,
    a.title AS assessment,
    s.score,
    a.maximum_score
FROM submissions s
JOIN enrolments e
    ON s.enrolment_id = e.enrolment_id
JOIN participants p
    ON e.participant_id = p.participant_id
JOIN assessments a
    ON s.assessment_id = a.assessment_id
ORDER BY s.score DESC;



-- Stage 3: Create the performance testing table

CREATE TABLE portfolio2_activity_log (
    log_id BIGSERIAL PRIMARY KEY,
    enrolment_id INT NOT NULL
        REFERENCES enrolments(enrolment_id),
    event_type VARCHAR(40) NOT NULL,
    event_time TIMESTAMP NOT NULL
);



-- Generate 100,000 fictional activity records
-- Assumes five enrolment records exist

INSERT INTO portfolio2_activity_log
(enrolment_id, event_type, event_time)
SELECT
    e.enrolment_id,
    CASE (g.n % 4)
        WHEN 0 THEN 'Login'
        WHEN 1 THEN 'Attendance'
        WHEN 2 THEN 'Assessment'
        ELSE 'Submission'
    END,
    TIMESTAMP '2026-01-01'
      + (g.n % 365) * INTERVAL '1 day'
      + (g.n % 86400) * INTERVAL '1 second'
FROM enrolments e
CROSS JOIN generate_series(1, 20000) AS g(n);

-- Update query planner statistics
ANALYZE portfolio2_activity_log;

-- Verify generated records
SELECT COUNT(*) AS total_activity_records
FROM portfolio2_activity_log;



-- Stage 4: Query plan before optimisation

EXPLAIN (ANALYZE, BUFFERS)
SELECT COUNT(*)
FROM portfolio2_activity_log
WHERE event_type = 'Assessment'
  AND event_time >= '2026-11-01'
  AND event_time < '2026-11-08';




-- STAGE 5: QUERY OPTIMISATION
-- Create composite index on event type and event time

CREATE INDEX idx_activity_type_time
ON portfolio2_activity_log (event_type, event_time);

-- Update PostgreSQL statistics
ANALYZE portfolio2_activity_log;




-- STAGE 5: VERIFY THE INDEX

SELECT
    indexname,
    indexdef
FROM pg_indexes
WHERE schemaname = 'public'
  AND tablename = 'portfolio2_activity_log'
ORDER BY indexname;




SELECT indexname, indexdef
FROM pg_indexes
WHERE schemaname = 'public'
AND tablename = 'portfolio2_activity_log';



EXPLAIN (ANALYZE, BUFFERS)
SELECT COUNT(*)
FROM portfolio2_activity_log
WHERE event_type = 'Assessment'
AND event_time >= '2026-11-01'
AND event_time < '2026-11-08';
