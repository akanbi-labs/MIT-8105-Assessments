# Portfolio 2 — Query Performance Analysis

**Course:** MIT 8103 — Advanced Database Systems  
**Case study:** Olaham Academy Training and Learner Management Database  
**Database:** PostgreSQL 18

## Query Performance Analysis

The Olaham Academy database was evaluated using PostgreSQL 18 and a synthetic dataset containing 100,000 activity records.

Before optimisation, PostgreSQL performed a **Sequential Scan**, resulting in an execution time of **25.981 ms** and **736 shared buffer hits**.

A composite index named `idx_activity_type_time` was created on the `event_type` and `event_time` columns.

After indexing, PostgreSQL selected an **Index Only Scan**, reducing the recorded execution time to **0.221 ms**, with **5 shared buffer hits** and **0 heap fetches**.

| Metric | Before indexing | After indexing |
|---|---|---|
| Scan method | Sequential Scan | Index Only Scan |
| Execution time | 25.981 ms | 0.221 ms |
| Shared buffer hits | 736 | 5 |
| Heap fetches | Not reported | 0 |

The observed execution time decreased by approximately **99.15%**, representing a **117.6-fold speedup** in this comparison.

These results demonstrate that the composite index substantially improved the execution of the tested query. However, these figures reflect individual executions: repeated measurements under similar conditions would be necessary to establish a reliable average. Query times can vary because of caching and system conditions, and maintaining indexes introduces additional storage and write overhead.

## Supporting Evidence

- `Execution_Plan_Before.png` — execution plan before indexing.
- `Index_Verification.png` — verification of the composite index.
- `Execution_Plan_After.png` — execution plan after indexing.

**Data note:** The activity records were generated synthetically for academic performance testing; they do not represent actual Olaham Academy learner activity.
