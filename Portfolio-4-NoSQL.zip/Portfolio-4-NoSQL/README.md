# Portfolio 4 — NoSQL and Advanced Data Models

**Course:** MIT 8103 — Advanced Database Systems  
**Case study:** Olaham Academy  
**Implementation:** MongoDB Community Server and MongoDB Compass  
**Assessment component:** 7 marks

## 1. Objective

Develop a document-oriented NoSQL example for the same Olaham Academy case study used in the previous portfolios. The prototype models learner portfolios containing flexible lists of skills and embedded project records, and demonstrates document insertion and retrieval.

> **Scope:** This is a simulated academic system using fictional learner data, not a copy of Olaham Academy's actual database.

## 2. Database and model

- **Database:** `olaham_academy_nosql`
- **Collection:** `student_portfolios`
- **Model type:** Document-oriented NoSQL (MongoDB)
- **Key fields:** `participant_id`, `full_name`, `email`, `programme`, `cohort`, `skills`, `projects`, and `portfolio_status`; MongoDB adds `_id`.

The `skills` field is an array of strings. The `projects` field is an array of embedded objects containing a project title, status and score.

### Example document

```json
{
  "participant_id": 1,
  "full_name": "Amina Yusuf",
  "email": "amina@example.com",
  "programme": "Digital Skills for Everyday Success",
  "cohort": "Cohort 3",
  "skills": ["Digital Literacy", "Online Collaboration", "Content Creation"],
  "projects": [
    {"title": "Digital Portfolio Project", "status": "Completed", "score": 78.5}
  ],
  "portfolio_status": "Active"
}
```

## 3. Implementation performed

1. Installed MongoDB Community Server and connected MongoDB Compass to `mongodb://localhost:27017`.
2. Created the `olaham_academy_nosql` database with the `student_portfolios` collection.
3. Inserted three fictional learner documents using Compass: **Amina Yusuf**, **David Okoro**, and **Sarah Bello**.
4. Expanded a stored document to inspect its `skills` array and embedded `projects` data.
5. Ran document filters and checked the matching records.

## 4. Query tests and results

In MongoDB Compass, open **Documents**, enter a filter and click **Find**.

| Query | Compass filter | Result from the sample data |
|---|---|---|
| Completed portfolios | `{ "portfolio_status": "Completed" }` | David Okoro (1 document) |
| Skill search | `{ "skills": "Content Creation" }` | Amina Yusuf and Sarah Bello (2 documents) |
| Project score threshold | `{ "projects.score": { "$gte": 80 } }` | David Okoro, score 85 (1 document) |

These filters demonstrate querying a top-level field, an array and an embedded document field. Results are specific to the three sample documents entered for this exercise.

## 5. Evidence / screenshots

Store the screenshots you actually captured in a `screenshots/` folder. Suggested names:

| File | Evidence |
|---|---|
| `01_NoSQL_Document.png` | First inserted learner document |
| `02_Expanded_Document.png` | Expanded skills and embedded project |
| `03_NoSQL_Collection.png` | Three stored participant documents |
| `04_NoSQL_Query_Completed.png` | Completed-portfolio filter |
| `05_NoSQL_Query_Skills.png` | Skill filter |
| `06_NoSQL_Query_Scores.png` | Score-threshold filter |

The names are organisational suggestions, not lecturer-prescribed filenames. Include only screenshots that you have actually taken; the screenshot numbering does not affect MongoDB.

## 6. How to reproduce

1. Start the local MongoDB service.
2. Open Compass and connect to `mongodb://localhost:27017`.
3. Open or create `olaham_academy_nosql` → `student_portfolios`.
4. Insert the example document above, then add the two other fictional learner portfolios used during the practical exercise. Avoid reinserting duplicates if these records already exist.
5. Run each filter in Section 4 and review the documents returned.

## 7. Model suitability

See [`model_suitability.md`](model_suitability.md) for the explanation of why MongoDB's arrays and embedded documents are appropriate for flexible learner portfolio data, as well as the limitations of this design.

## 8. Individual technical reflection — review and personalise

In this exercise, I worked with MongoDB Compass to store learner information in JSON-like documents instead of relational tables. I examined how arrays and embedded project objects can be queried using MongoDB filters. The exercise helped me understand the differences between document-oriented storage and the relational model used in the earlier portfolios.

**Before submission:** Update this paragraph to reflect the actions you personally performed, any errors you encountered and how you confirmed your results.

## 9. References and AI-use declaration — verify before submission

- MongoDB Manual: https://www.mongodb.com/docs/manual/
- MongoDB Compass documentation: https://www.mongodb.com/docs/compass/
- MIT 8103 course assessment brief (provided by the lecturer).
