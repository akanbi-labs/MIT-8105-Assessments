# NoSQL Model Suitability — Olaham Academy

**Course:** MIT 8103 — Advanced Database Systems  
**Portfolio:** 4 — NoSQL and Advanced Data Models  
**Case study:** Olaham Academy (proposed learner portfolio system)

## Selected model

A **document-oriented NoSQL model**, implemented with **MongoDB Community Server and MongoDB Compass**, was selected to represent learner portfolios. The database is named `olaham_academy_nosql`, and its collection is `student_portfolios`.

## Why the model is suitable

Olaham Academy's proposed learner portfolio system needs to store basic participant information alongside variable-length lists of skills and projects. A MongoDB document can keep these related details together:

- **Simple fields:** participant ID, name, email, programme, cohort and portfolio status.
- **Arrays:** `skills`, which can contain different numbers of skills for different learners.
- **Embedded documents:** `projects`, which can contain project titles, completion statuses and scores.

This arrangement makes it straightforward to retrieve a learner's portfolio as one document without joining several tables. Its flexible structure also allows portfolios to evolve as different training programmes introduce different project information.

## Evidence from the practical implementation

Three fictional learner documents were inserted into `student_portfolios`: Amina Yusuf, David Okoro and Sarah Bello. In MongoDB Compass, the following filters were tested:

| Filter | Purpose | Observed/expected matching learners |
|---|---|---|
| `{ "portfolio_status": "Completed" }` | Find completed portfolios | David Okoro |
| `{ "skills": "Content Creation" }` | Find learners with a specified skill | Amina Yusuf and Sarah Bello |
| `{ "projects.score": { "$gte": 80 } }` | Find portfolios with a project score of at least 80 | David Okoro (85) |

The filter results demonstrate queries over ordinary fields, array contents and embedded document fields.

## Relationship to the relational database

MongoDB is used here for **flexible learner portfolio content**. The PostgreSQL database developed in Portfolio 1 remains appropriate for structured records and enforced relationships between participants, programmes, cohorts, enrolments, assessments and submissions. This is a comparison of design suitability, not a claim that the two databases have been integrated or synchronised.

## Limitations and conclusion

Embedding project information is convenient for retrieving a whole portfolio, but repeated programme or cohort labels may become inconsistent if they change. MongoDB's flexible schema also does not automatically enforce the foreign-key relationships already defined in PostgreSQL. Production use would require validation, access controls, and a clear policy for updates and consistency.

For this small academic prototype, the document model is suitable because learner skills and projects vary between participants. **All records are fictional** and do not represent Olaham Academy's actual internal data.
