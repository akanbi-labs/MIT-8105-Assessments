
/*
 MIT 8103 - ADVANCED DATABASE SYSTEMS
 PORTFOLIO 4: NoSQL and Advanced Data Models
 CASE STUDY: OLAHAM ACADEMY

 Database: olaham_academy_nosql
 Collection: student_portfolios

 All participant data is fictional.
 Run using MongoDB Shell (mongosh).
*/

// 1. Select Database
use("olaham_academy_nosql");

// 2. Select Collection
const portfolios = db.student_portfolios;

// 3. Insert Sample Documents
// Upsert prevents duplicate participant records.

const students = [
  {
    participant_id: 1,
    full_name: "Amina Yusuf",
    email: "amina@example.com",
    programme: "Digital Skills for Everyday Success",
    cohort: "Cohort 3",
    skills: [
      "Digital Literacy",
      "Online Collaboration",
      "Content Creation"
    ],
    projects: [
      {
        title: "Digital Portfolio Project",
        status: "Completed",
        score: 78.5
      }
    ],
    portfolio_status: "Active"
  },
  {
    participant_id: 2,
    full_name: "David Okoro",
    email: "david@example.com",
    programme: "Digital Skills for Everyday Success",
    cohort: "Cohort 3",
    skills: [
      "Data Analysis",
      "Digital Communication",
      "Presentation Skills"
    ],
    projects: [
      {
        title: "Digital Skills Capstone Project",
        status: "Completed",
        score: 85
      }
    ],
    portfolio_status: "Completed"
  },
  {
    participant_id: 3,
    full_name: "Sarah Bello",
    email: "sarah@example.com",
    programme: "Digital Skills for Everyday Success",
    cohort: "Cohort 3",
    skills: [
      "Digital Literacy",
      "Content Creation"
    ],
    projects: [],
    portfolio_status: "Active"
  }
];

students.forEach(student => {
  portfolios.updateOne(
    { participant_id: student.participant_id },
    { $set: student },
    { upsert: true }
  );
});

// 4. Display All Documents
print("ALL STUDENT PORTFOLIOS");
printjson(portfolios.find({}).toArray());

// 5. Query Completed Portfolios
print("COMPLETED PORTFOLIOS");
printjson(
  portfolios.find({
    portfolio_status: "Completed"
  }).toArray()
);

// 6. Query Participants by Skill
print("CONTENT CREATION SKILLS");
printjson(
  portfolios.find({
    skills: "Content Creation"
  }).toArray()
);

// 7. Query Project Scores >= 80
print("PROJECT SCORES OF 80 AND ABOVE");
printjson(
  portfolios.find({
    "projects.score": { $gte: 80 }
  }).toArray()
);

// 8. Count Documents
print("TOTAL DOCUMENTS");
print(portfolios.countDocuments({}));
